#ifndef SIM_PROC_H
#define SIM_PROC_H







char pc[20];

int ROB_void = 0;
int IQ_void = 0;
int WB_void = 0;


int ROB_1 = 0;
int IQ_1 = 0;

int FRONT_linklist = 0;
int END_linklist = 0;

int Pipeline_stage = 1;

int IQ_zero = 0;
int ROB_zero = 0;
int WB_zero = 0;


int IQ_finish = 0;
int ROB_finish = 0;


int EX_first = 0;
int WB_first = 0;
int IQ_firsT = 0;

int Retire_finish = 0;

int Cycle = 0;

int DE_pipeline_stage = 0;
int RN_pipeline_stage = 0;
int RR_pipeline_stage = 0;
int DI_pipeline_stage = 0;


int csgo;
int trigger;


int empty = 0;






// Put additional data structures here as per your requirement

#endif
